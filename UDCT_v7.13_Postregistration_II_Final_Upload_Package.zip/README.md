# UDCT v7.13 Post-registration II — Hydrus I Jeans Sign-Boundary and Hessian Reproducibility Audit

**Status:** Upload-ready manuscript (2026-10-22). Zenodo DOI reserved; registration takes effect upon publication.

**GitHub:** https://github.com/wspaik5/UDCT_v7.13_Postregistration_II_Reproducibility_Audit  
**Zenodo DOI (reserved):** https://doi.org/10.5281/zenodo.23559995  
**Original Post-registration I DOI:** https://doi.org/10.5281/zenodo.23539127  
**Original Post-registration I GitHub:** https://github.com/wspaik5/UDCT_v7.13_Postregistration_Hessian_Archive  
**Original preregistration DOI:** https://doi.org/10.5281/zenodo.23342971  
**Original preregistration GitHub:** https://github.com/wspaik5/UDCT_v7.13_Preregistration_Jeans_Boundary_Refinement

## Main result
24 candidate brackets; 48 endpoint occurrences (not independent physical trials); 288 saved profiles of 1,200 common radii; archived 18 robust-positive / 30 unresolved / 0 robust-negative endpoint occurrences; 0 validated strict brackets. A new post-hoc checker found no shared-radius six-arm negative witness. It does NOT independently rerun the physical solver, reconstruct all native-grid minima, validate a full 3D Hessian, or fit observed individual Hydrus I stellar velocities.

## Endpoint duplicates
Some endpoint occurrences reuse model settings. Rounded E/tau/common-minimum fingerprints yield **32 numerical groups**, but grouping by numeric output is NOT a proven unique-physics count. Use the full law, beta, screening length and frozen model parameters for definitive deduplication. Do not claim 48 independent cases.

## B01
At beta=0.35, ell=1 pc: native minimum approximately -0.158964; common minimum +0.231148; E=0.0235645; tau=0.117822. Their difference is not a valid direct estimate of solver discretization error because radial domains differ. Native and common radius bounds are NOT independently established by this package.

## Package files
- `UDCT_v7.13_Postregistration_II_Reproducibility_Audit.pdf` — revised manuscript with three scientific figures.
- `independent_array_check.py` — retrospective saved-array checker. Requires original Hessian archive ZIP, NumPy; see script for path assumptions.
- `ENDPOINT_COMMON_ARRAY_CHECK.csv`, `ARRAY_AUDIT_SUMMARY.json` — saved-array results.
- `preregistration_plan.json` — original frozen protocol plan, unmodified.
- `PROVENANCE_AND_AUDIT.json` — original source DOI/GitHub and actual SHA-256.
- `Figure_*.png` — publication figures.
- `SHA256SUMS.txt` — hashes of package members, excluding itself.

## Reproduction
Place `UDCT_v7.13_Original_Hessian_Research_Archive.zip` beside the audit script in the path expected by `independent_array_check.py`, or adapt the input path without changing its numerical logic. Execute `python independent_array_check.py` after installing NumPy. Original archive is NOT bundled to avoid duplication; obtain it from original Post-registration I record. The new checker is NOT the missing original six-arm prototype.

## Release checklist
1. GitHub repository and Zenodo DOI reserved/created (see links above).
2. This PDF and README carry both links; verify the URLs before publication.
3. Upload this PDF and the companion ZIP to Zenodo; upload the source files to GitHub.
4. Verify any manuscript references explicitly marked as needing bibliographic confirmation.
5. Publish only after confirming the uploads and metadata; retain original I records unchanged.

## Interpretation
Retrospective evidence audit, not a new gravity-law discovery, 3D Hessian validation or observed-star likelihood fit. v7.14 is only a proposed future preregistration preview.
