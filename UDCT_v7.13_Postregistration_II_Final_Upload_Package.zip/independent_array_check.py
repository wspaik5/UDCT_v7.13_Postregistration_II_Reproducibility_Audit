#!/usr/bin/env python3
"""Independent post-hoc audit of saved common-radius arrays; not a physics rerun."""
import io,zipfile,json,csv,hashlib,collections
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parent
archive=Path(__file__).resolve().parents[1]/'UDCT_v7.13_Original_Hessian_Research_Archive.zip'
with zipfile.ZipFile(archive) as z:
    name=next(n for n in z.namelist() if 'All_Common_Profiles_' in n and n.endswith('.npz'))
    arrays=np.load(io.BytesIO(z.read(name)),allow_pickle=False)
    groups=collections.defaultdict(list)
    for k in arrays.files:
        parts=k.split('|')
        if len(parts)!=4: raise ValueError('Unexpected key '+k)
        groups[(parts[0],parts[1])].append((k,arrays[k]))
    rows=[]
    for (target,coord),items in sorted(groups.items()):
        if len(items)!=6:raise ValueError(f'Expected six arms {target} {coord}: {len(items)}')
        stack=np.stack([v for _,v in sorted(items)])
        if stack.shape!=(6,1200) or not np.isfinite(stack).all():raise ValueError('Nonfinite or shape mismatch')
        e=float(np.max(np.max(stack,axis=0)-np.min(stack,axis=0)))
        tau=max(1e-8,5*e)
        common_min=float(stack.min())
        positive_common=bool(common_min>tau)
        negative_witness=bool(np.any(np.all(stack < -tau,axis=0)))
        rows.append(dict(target=target,coordinate=coord,E=e,tau=tau,common_min=common_min,
                         common_positive=positive_common,common_negative_witness=negative_witness,
                         common_radius_points=1200,arms=6))
    inventory_name=next(n for n in z.namelist() if 'Six_Arm_Inventory_' in n and n.endswith('.json'))
    inventory=json.loads(z.read(inventory_name))
    saved={t['target']:t for t in inventory['targets']}
    mismatches=[]
    for r in rows:
        status=next((v for k,v in saved[r['target']]['endpoints'].items() if float(k)==float(r['coordinate'])),None)
        r['archived_status']=status
        if status=='robust_positive' and not r['common_positive']:
            mismatches.append({'target':r['target'],'coordinate':r['coordinate'],'issue':'archived positive not supported by common arrays'})
        if status=='robust_negative' and not r['common_negative_witness']:
            mismatches.append({'target':r['target'],'coordinate':r['coordinate'],'issue':'archived negative lacks shared-radius witness'})
    summary=dict(kind='POST_HOC_SAVED_ARRAY_AUDIT_NOT_PHYSICS_RERUN',archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),
        array_member=name,groups=len(rows),profiles=len(arrays.files),points_per_profile=1200,
        common_positive=sum(r['common_positive'] for r in rows),common_negative_witness=sum(r['common_negative_witness'] for r in rows),
        archived_robust_positive=sum(r['archived_status']=='robust_positive' for r in rows),
        archived_unresolved=sum(r['archived_status']=='unresolved_numerical_margin' for r in rows),
        archived_status_mismatches=mismatches,
        limitations=['Native-grid minima absent from NPZ; common-positive is necessary but not sufficient for full robust-positive classification.',
                     'Does not execute original six-arm gravity/Jeans solver.',
                     'Does not validate full 3-D Hessian, observational likelihood, or preregistration timing.'])
    (ROOT/'ARRAY_AUDIT_SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n')
    with (ROOT/'ENDPOINT_COMMON_ARRAY_CHECK.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    print(json.dumps(summary,indent=2))
